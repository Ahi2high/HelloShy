﻿using System.Windows;

namespace HelloShyanne
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void OkClick(object sender, RoutedEventArgs e)
        {
            string shyanneText = ShyanneTextBox.Text;
            MessageBox.Show($"Hello {shyanneText}");
        }
    }
}
